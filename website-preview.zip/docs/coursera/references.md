---
title: "Leadership for Cancer Informatics Research"
output: html_document
bibliography: [book.bib, packages.bib]
biblio-style: apalike
link-citations: yes
---

# References {-}
